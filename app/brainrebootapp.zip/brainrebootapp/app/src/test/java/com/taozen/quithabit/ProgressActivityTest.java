package com.taozen.quithabit;

import org.junit.Test;

public class ProgressActivityTest {

    @Test
    public void onCreate1() {
    }
}